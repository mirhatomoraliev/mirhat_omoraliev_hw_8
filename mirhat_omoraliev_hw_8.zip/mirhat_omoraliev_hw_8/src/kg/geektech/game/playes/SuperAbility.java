package kg.geektech.game.playes;

public enum SuperAbility {
    CRITICAL_DAMAGE, HEAL, BOOST, SAVE_DAMAGE_AND_REVERT
}
