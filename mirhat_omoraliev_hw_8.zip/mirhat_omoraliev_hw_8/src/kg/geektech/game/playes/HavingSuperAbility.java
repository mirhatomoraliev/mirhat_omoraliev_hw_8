package kg.geektech.game.playes;

public interface HavingSuperAbility {
    void applySuperPower(Boss boss, Hero[] heroes);
}
